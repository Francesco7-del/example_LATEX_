DROP SCHEMA IF EXISTS unipi_project;
CREATE SCHEMA unipi_project DEFAULT CHARACTER SET utf8;
USE unipi_project;

SET GLOBAL event_scheduler = on;
